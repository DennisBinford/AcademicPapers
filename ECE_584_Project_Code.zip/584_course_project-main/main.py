"""
main.py - Configurable fractal self-avoidance verification with timeout and comparison plots

Configure fractals, depths, grid sizes, and timeout to test.
Outputs detailed CSV files with performance metrics and comparison plots across fractals.
Skips to next fractal if all grid sizes timeout for a given depth.
Excludes timeout results from data saving and summary printouts.
"""

import time
import os
from datetime import datetime
from fractal_generators import FractalGenerator
from helper import (
    calculate_memory_usage,
    verify_with_grid_size,
    format_time,
    print_header,
    save_results_to_csv,
    print_depth_summary,
    plot_fractal_comparison_at_grid_size
)
from helper_plotting import (
    plot_single_grid_visualization,
    plot_verification_times_for_depth,
    plot_verification_times_vs_depth,
    plot_segment_count_vs_depth,
    plot_grid_comparison_at_depth
)
import csv
from datetime import datetime as dt

VERIFICATION_TIMEOUT = 120

# Output directories
RESULTS_DIR = "verification_results"
PLOTS_DIR = "plots"
VERIFICATION_TIME_PLOTS_DIR = "verification_time_plots"
DEPTH_SCALING_PLOTS_DIR = "depth_scaling_plots"
SEGMENT_SCALING_PLOTS_DIR = "segment_scaling_plots"
COMPARISON_PLOTS_DIR = "comparison_plots"
GRID_COMPARISON_PLOTS_DIR = "grid_comparison_plots"  # NEW: Grid size comparison at specific depths

# Enable/disable plotting
ENABLE_PLOTTING = True
ENABLE_INDIVIDUAL_GRID_PLOTS = False
ENABLE_VERIFICATION_TIME_PLOTS = True
ENABLE_DEPTH_SCALING_PLOTS = True
ENABLE_SEGMENT_SCALING_PLOTS = True
ENABLE_COMPARISON_PLOTS = True
ENABLE_GRID_COMPARISON_PLOTS = True  # NEW: Grid size comparison plots

# Fractal configurations
FRACTAL_CONFIG = {
    'koch': {
        'name': 'Koch Curve',
        'method': 'generate_koch_curve',
        'depths': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    },
    'dragon': {
        'name': 'Heighway Dragon',
        'method': 'generate_heighway_dragon',
        'depths': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    },
    'levy': {
        'name': 'Lévy C Curve',
        'method': 'generate_levy_curve',
        'depths': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    },
    'hilbert': {
        'name': 'Hilbert Curve',
        'method': 'generate_hilbert_curve',
        'depths': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    },
    'sierpinski': {
        'name': 'Sierpiński Arrowhead',
        'method': 'generate_sierpinski_arrowhead',
        'depths': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    },
    'gosper': {
        'name': 'Gosper Curve',
        'method': 'generate_gosper_curve',
        'depths': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    }
}

# Spatial index grid sizes to test
GRID_SIZES = [-1, 0, 1, 10, 100]


def plot_grid_comparison_at_depth(all_fractal_data, depth, output_dir="grid_comparison_plots"):
    """Create comparison plot showing all fractals across different grid sizes at a specific depth."""
    import matplotlib.pyplot as plt

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    fig, ax = plt.subplots(figsize=(12, 7))
    colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#6A994E', '#BC4B51']
    markers = ['o', 's', '^', 'D', 'v', 'p']

    for idx, (fractal_key, data) in enumerate(sorted(all_fractal_data.items())):
        fractal_name = data['name']
        all_depth_results = data['depth_results']

        # Check if this fractal has data for this depth
        if depth not in all_depth_results:
            continue

        grid_sizes = []
        times_ms = []

        depth_data = all_depth_results[depth]
        for grid_size in sorted(depth_data['grid_results'].keys()):
            result = depth_data['grid_results'][grid_size]
            if not result.get('timed_out', False):
                grid_sizes.append(grid_size)
                times_ms.append(result['verify_time'] * 1000)

        if grid_sizes:
            ax.plot(grid_sizes, times_ms, marker=markers[idx % len(markers)], markersize=8,
                    linewidth=2.5, label=fractal_name, color=colors[idx % len(colors)])

    ax.set_xlabel('Grid Size', fontsize=12, fontweight='bold')
    ax.set_ylabel('Verification Time (ms)', fontsize=12, fontweight='bold')
    ax.legend(loc='best', fontsize=10, framealpha=0.9)
    ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.8)

    ax.set_title(f"Grid Size Performance Comparison\nDepth {depth}",
                 fontsize=14, fontweight='bold', pad=15)

    if times_ms and max(times_ms) / min([t for t in times_ms if t > 0]) > 10:
        ax.set_yscale('log')
        ax.set_ylabel('Verification Time (ms, log scale)', fontsize=12, fontweight='bold')

    plt.tight_layout()

    timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
    filename = os.path.join(output_dir, f"grid_comparison_d{depth}_{timestamp}.png")
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()

    return filename


def save_results_to_csv(fractal_key, fractal_name, all_depth_results, results_dir):
    """Save results to CSV, excluding timed out entries."""
    timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
    filename = os.path.join(results_dir, f'{fractal_key}_results_{timestamp}.csv')

    fieldnames = ['depth', 'num_segments', 'memory_bytes', 'memory_kb', 'memory_mb', 'grid_size',
                  'verify_time_sec', 'verify_time_ms', 'speedup_vs_slowest', 'pairs_checked',
                  'pairs_skipped', 'optimization_ratio', 'is_self_avoiding', 'num_violations']

    with open(filename, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for depth in sorted(all_depth_results.keys()):
            depth_data = all_depth_results[depth]
            num_segments = depth_data['num_segments']
            memory_info = depth_data['memory']

            # Filter out timed out results
            valid_results = {gs: result for gs, result in depth_data['grid_results'].items()
                           if not result.get('timed_out', False)}

            if not valid_results:
                continue  # Skip this depth entirely if all results timed out

            slowest_time = max(result['verify_time'] for result in valid_results.values())

            for grid_size in sorted(valid_results.keys()):
                result = valid_results[grid_size]
                speedup = slowest_time / result['verify_time'] if slowest_time > 0 and result['verify_time'] > 0 else 1.0

                writer.writerow({
                    'depth': depth,
                    'num_segments': num_segments,
                    'memory_bytes': memory_info['total_bytes'],
                    'memory_kb': memory_info['total_kb'],
                    'memory_mb': memory_info['total_mb'],
                    'grid_size': grid_size,
                    'verify_time_sec': result['verify_time'],
                    'verify_time_ms': result['verify_time'] * 1000,
                    'speedup_vs_slowest': speedup,
                    'pairs_checked': result['pairs_checked'],
                    'pairs_skipped': result['pairs_skipped'],
                    'optimization_ratio': result['optimization_ratio'],
                    'is_self_avoiding': result['is_avoiding'],
                    'num_violations': result['num_violations']
                })

    print(f"  💾 Results saved to: {filename}")
    return filename


def print_depth_summary(fractal_name, depth, num_segments, memory_mb, grid_results):
    """Print a summary for one depth with all grid sizes, excluding timeouts."""
    print(f"\n  Depth {depth}: {num_segments:,} segments, {memory_mb:.2f} MB")

    # Filter out timed out results
    valid_results = {gs: result for gs, result in grid_results.items()
                    if not result.get('timed_out', False)}

    if not valid_results:
        print(f"  All grid sizes timed out - no summary available")
        return

    print(f"  {'Grid':<15} {'Time':<12} {'Speedup':<10} {'Pairs Checked':<15} "
          f"{'Pairs Skipped':<15} {'Opt Ratio':<12} {'Result':<20}")
    print(f"  {'-' * 110}")

    slowest_time = max(result['verify_time'] for result in valid_results.values())

    for grid_size in sorted(valid_results.keys()):
        result = valid_results[grid_size]
        grid_str = "-1 (Raw Z3)" if grid_size == -1 else "0 (BB only)" if grid_size == 0 else f"{grid_size}x{grid_size}"
        time_str = format_time(result['verify_time'])

        speedup = slowest_time / result['verify_time'] if slowest_time > 0 and result['verify_time'] > 0 else 1.0
        speedup_str = f"{speedup:.2f}x"

        # Status: avoiding or violations
        if result['is_avoiding']:
            status = "✓ Avoiding"
        else:
            status = f"✗ {result['num_violations']} violations"

        print(f"  {grid_str:<15} {time_str:<12} {speedup_str:<10} "
              f"{result['pairs_checked']:<15,} {result['pairs_skipped']:<15,} "
              f"{result['optimization_ratio']:.2%}{'':<6} {status:<20}")


def plot_fractal_comparison_at_grid_size(all_fractal_data, grid_size, output_dir="comparison_plots"):
    """Create comparison plot for all fractals at specific grid size, excluding timeouts."""
    import matplotlib.pyplot as plt

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    fig, ax = plt.subplots(figsize=(12, 7))
    colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#6A994E', '#BC4B51']
    markers = ['o', 's', '^', 'D', 'v', 'p']

    for idx, (fractal_key, data) in enumerate(sorted(all_fractal_data.items())):
        fractal_name = data['name']
        all_depth_results = data['depth_results']
        depths, times_ms = [], []

        for depth in sorted(all_depth_results.keys()):
            if grid_size in all_depth_results[depth]['grid_results']:
                result = all_depth_results[depth]['grid_results'][grid_size]
                if not result.get('timed_out', False):
                    depths.append(depth)
                    times_ms.append(result['verify_time'] * 1000)

        if depths:
            ax.plot(depths, times_ms, marker=markers[idx % len(markers)], markersize=8,
                    linewidth=2.5, label=fractal_name, color=colors[idx % len(colors)])

    ax.set_xlabel('Depth', fontsize=12, fontweight='bold')
    ax.set_ylabel('Verification Time (ms)', fontsize=12, fontweight='bold')
    ax.legend(loc='best', fontsize=10, framealpha=0.9)
    ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.8)

    grid_str = "Raw Z3" if grid_size == -1 else "Bounding Box Only" if grid_size == 0 else f"{grid_size}×{grid_size} Grid"
    ax.set_title(f"Fractal Comparison\n{grid_str}", fontsize=14, fontweight='bold', pad=15)

    if times_ms and max(times_ms) / min([t for t in times_ms if t > 0]) > 10:
        ax.set_yscale('log')

    plt.tight_layout()

    timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
    filename = os.path.join(output_dir, f"fractal_comparison_g{grid_size}_{timestamp}.png")
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()

    return filename


def main():
    """Main verification program."""
    print_header("FRACTAL SELF-AVOIDANCE VERIFICATION")
    print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"\nTimeout per verification: {VERIFICATION_TIMEOUT}s ({VERIFICATION_TIMEOUT/60:.1f} minutes)")
    print(f"Testing {len(FRACTAL_CONFIG)} fractals with grid sizes: {GRID_SIZES}")
    print(f"Results will be saved to: {RESULTS_DIR}/")
    print(f"\n⚠️  Note: If all grid sizes timeout for a depth, will skip to next fractal")
    print(f"⚠️  Note: If a grid size times out, it will be skipped for subsequent depths")
    print(f"⚠️  Note: Timed out results are excluded from CSV and summaries")

    if ENABLE_PLOTTING:
        print(f"\nPlots will be saved to: {PLOTS_DIR}/")
        if ENABLE_INDIVIDUAL_GRID_PLOTS:
            print(f"  - Individual grid plots: ENABLED")
        if ENABLE_VERIFICATION_TIME_PLOTS:
            print(f"  - Verification time plots: ENABLED ({VERIFICATION_TIME_PLOTS_DIR}/)")
        if ENABLE_DEPTH_SCALING_PLOTS:
            print(f"  - Depth scaling plots: ENABLED ({DEPTH_SCALING_PLOTS_DIR}/)")
        if ENABLE_SEGMENT_SCALING_PLOTS:
            print(f"  - Segment scaling plots: ENABLED ({SEGMENT_SCALING_PLOTS_DIR}/)")
        if ENABLE_COMPARISON_PLOTS:
            print(f"  - Fractal comparison plots: ENABLED ({COMPARISON_PLOTS_DIR}/)")
        if ENABLE_GRID_COMPARISON_PLOTS:
            print(f"  - Grid comparison plots: ENABLED ({GRID_COMPARISON_PLOTS_DIR}/)")
    else:
        print("\nPlotting is DISABLED")

    # Create output directories
    for directory in [RESULTS_DIR, PLOTS_DIR, VERIFICATION_TIME_PLOTS_DIR,
                      DEPTH_SCALING_PLOTS_DIR, SEGMENT_SCALING_PLOTS_DIR,
                      COMPARISON_PLOTS_DIR, GRID_COMPARISON_PLOTS_DIR]:
        if not os.path.exists(directory):
            os.makedirs(directory)

    total_start = time.time()
    all_csv_files = []
    all_plot_files = []
    all_fractal_data = {}

    # Process each fractal
    for idx, (fractal_key, config) in enumerate(FRACTAL_CONFIG.items(), 1):
        print_header(f"[{idx}/{len(FRACTAL_CONFIG)}] {config['name'].upper()}")

        generator = FractalGenerator()
        method = getattr(generator, config['method'])

        fractal_results = {}
        skip_remaining_depths = False
        skipped_grid_sizes = set()  # Track which grid sizes to skip

        # Process each depth
        for depth in config['depths']:
            if skip_remaining_depths:
                print(f"\n  Skipping depth {depth} (all grid sizes timed out at previous depth)")
                continue

            print(f"\n  Processing depth {depth}...")

            # Generate fractal
            gen_start = time.time()
            segments = method(depth)
            gen_time = time.time() - gen_start

            # Calculate memory usage
            memory_info = calculate_memory_usage(segments)

            print(f"    Generated {len(segments):,} segments in {format_time(gen_time)}")
            print(f"    Memory: {memory_info['total_mb']:.2f} MB")

            # Test with each grid size
            grid_results = {}
            all_timed_out = True
            newly_timed_out = []

            for grid_size in GRID_SIZES:
                # Skip if this grid size already timed out at a previous depth
                if grid_size in skipped_grid_sizes:
                    grid_str = "-1 (Raw Z3)" if grid_size == -1 else "0 (BB only)" if grid_size == 0 else f"{grid_size}x{grid_size}"
                    print(f"    Skipping {grid_str} (timed out at earlier depth)")
                    # Create a timeout result for consistency
                    grid_results[grid_size] = {
                        'grid_size': grid_size,
                        'verify_time': VERIFICATION_TIMEOUT,
                        'is_avoiding': False,
                        'violations': [],
                        'num_violations': 0,
                        'pairs_checked': 0,
                        'pairs_skipped': 0,
                        'optimization_ratio': 0,
                        'timed_out': True
                    }
                    continue

                grid_str = "-1 (Raw Z3)" if grid_size == -1 else "0 (BB only)" if grid_size == 0 else f"{grid_size}x{grid_size}"
                print(f"    Verifying with {grid_str}...", end=' ', flush=True)

                try:
                    result = verify_with_grid_size(segments, grid_size, VERIFICATION_TIMEOUT)
                    grid_results[grid_size] = result

                    if not result.get('timed_out', False):
                        all_timed_out = False
                        print(f"✓ {format_time(result['verify_time'])}")
                    else:
                        print(f"⏱️ TIMEOUT ({VERIFICATION_TIMEOUT}s)")
                        newly_timed_out.append(grid_size)
                except Exception as e:
                    # If we somehow still get an exception, treat it as a timeout
                    error_msg = str(e).lower()
                    is_timeout_error = 'timeout' in error_msg or 'timed out' in error_msg

                    if is_timeout_error:
                        print(f"⏱️ TIMEOUT ({VERIFICATION_TIMEOUT}s)")
                        newly_timed_out.append(grid_size)
                    else:
                        print(f"✗ Error: {e}")
                        all_timed_out = False  # Only non-timeout errors break the "all timeout" check

                    # Create a timeout result regardless
                    grid_results[grid_size] = {
                        'grid_size': grid_size,
                        'verify_time': VERIFICATION_TIMEOUT,
                        'is_avoiding': False,
                        'violations': [],
                        'num_violations': 0,
                        'pairs_checked': 0,
                        'pairs_skipped': 0,
                        'optimization_ratio': 0,
                        'timed_out': True  # Always mark as timeout for consistency
                    }

            # Add newly timed out grid sizes to the skip list for future depths
            for gs in newly_timed_out:
                skipped_grid_sizes.add(gs)
                gs_str = "-1 (Raw Z3)" if gs == -1 else "0 (BB only)" if gs == 0 else f"{gs}x{gs}"
                print(f"    → Will skip {gs_str} for remaining depths")

            # Check if all grid sizes timed out (including previously skipped ones)
            if all_timed_out:
                print(f"\n  ⚠️  ALL grid sizes timed out at depth {depth}!")
                print(f"  Skipping remaining depths for {config['name']} and moving to next fractal...")
                skip_remaining_depths = True

            # Store results for this depth
            fractal_results[depth] = {
                'num_segments': len(segments),
                'gen_time': gen_time,
                'memory': memory_info,
                'grid_results': grid_results,
                'segments': segments
            }

            # Print summary (excludes timeouts)
            print_depth_summary(config['name'], depth, len(segments), memory_info['total_mb'], grid_results)

            # Generate plots if enabled (only for non-timeout results)
            if ENABLE_PLOTTING and not all_timed_out:
                print(f"\n  Generating plots for depth {depth}...")

                try:
                    # Find first non-timeout result for main visualization
                    first_valid_grid_size = None
                    for gs in GRID_SIZES:
                        if gs in grid_results and not grid_results[gs].get('timed_out', False):
                            first_valid_grid_size = gs
                            break

                    if first_valid_grid_size is not None:
                        first_result = grid_results[first_valid_grid_size]

                        fractal_plot = plot_single_grid_visualization(
                            segments, first_result['violations'], config['name'], depth,
                            first_valid_grid_size, first_result['verify_time'], PLOTS_DIR
                        )
                        if fractal_plot:
                            all_plot_files.append(fractal_plot)
                            print(f"    ✓ Fractal plot saved: {os.path.basename(fractal_plot)}")

                    # Verification time comparison (only non-timeout results)
                    if ENABLE_VERIFICATION_TIME_PLOTS:
                        valid_results = {gs: result for gs, result in grid_results.items()
                                       if not result.get('timed_out', False)}
                        if valid_results:
                            time_plot = plot_verification_times_for_depth(
                                config['name'], depth, valid_results, VERIFICATION_TIME_PLOTS_DIR
                            )
                            if time_plot:
                                all_plot_files.append(time_plot)
                                print(f"    ✓ Verification time plot saved: {os.path.basename(time_plot)}")

                    # Individual grid plots (optional, non-timeout only)
                    if ENABLE_INDIVIDUAL_GRID_PLOTS:
                        for grid_size, result in grid_results.items():
                            if not result.get('timed_out', False):
                                individual_plot = plot_single_grid_visualization(
                                    segments, result['violations'], config['name'], depth,
                                    grid_size, result['verify_time'], PLOTS_DIR
                                )
                                if individual_plot:
                                    all_plot_files.append(individual_plot)

                except Exception as e:
                    print(f"    ✗ Plotting error: {e}")

        # Only save results if we have some non-timeout data
        if fractal_results:
            # Check if there's any non-timeout data
            has_valid_data = any(
                any(not result.get('timed_out', False)
                    for result in depth_data['grid_results'].values())
                for depth_data in fractal_results.values()
            )

            if has_valid_data:
                # Save results to CSV
                print(f"\n  Saving results for {config['name']}...")
                csv_file = save_results_to_csv(fractal_key, config['name'], fractal_results, RESULTS_DIR)
                all_csv_files.append(csv_file)

                # Store fractal data for comparison plots
                all_fractal_data[fractal_key] = {
                    'name': config['name'],
                    'depth_results': fractal_results
                }

                # Generate per-fractal plots
                if ENABLE_PLOTTING:
                    if ENABLE_DEPTH_SCALING_PLOTS:
                        print(f"\n  Generating depth scaling plots for {config['name']}...")
                        try:
                            scaling_plots = plot_verification_times_vs_depth(
                                config['name'], fractal_results, DEPTH_SCALING_PLOTS_DIR
                            )
                            all_plot_files.extend(scaling_plots)
                            print(f"    ✓ Generated {len(scaling_plots)} depth scaling plots")
                        except Exception as e:
                            print(f"    ✗ Depth scaling plot error: {e}")

                    if ENABLE_SEGMENT_SCALING_PLOTS:
                        print(f"\n  Generating segment scaling plot for {config['name']}...")
                        try:
                            segment_plot = plot_segment_count_vs_depth(
                                config['name'], fractal_results, SEGMENT_SCALING_PLOTS_DIR
                            )
                            all_plot_files.append(segment_plot)
                            print(f"    ✓ Segment scaling plot saved: {os.path.basename(segment_plot)}")
                        except Exception as e:
                            print(f"    ✗ Segment scaling plot error: {e}")
            else:
                print(f"\n  ⚠️  No valid (non-timeout) data for {config['name']}, skipping CSV save")

    # Generate cross-fractal comparison plots
    if ENABLE_PLOTTING and ENABLE_COMPARISON_PLOTS and len(all_fractal_data) > 1:
        print_header("GENERATING CROSS-FRACTAL COMPARISON PLOTS")

        for grid_size in GRID_SIZES:
            grid_str = "Raw Z3" if grid_size == -1 else "Bounding Box Only" if grid_size == 0 else f"{grid_size}×{grid_size} Grid"
            print(f"\n  Creating comparison plot for {grid_str}...")

            try:
                comparison_plot = plot_fractal_comparison_at_grid_size(
                    all_fractal_data, grid_size, COMPARISON_PLOTS_DIR
                )
                all_plot_files.append(comparison_plot)
                print(f"    ✓ Comparison plot saved: {os.path.basename(comparison_plot)}")
            except Exception as e:
                print(f"    ✗ Comparison plot error: {e}")

    # Generate grid size comparison plots at specific depths
    if ENABLE_PLOTTING and ENABLE_GRID_COMPARISON_PLOTS and len(all_fractal_data) > 1:
        print_header("GENERATING GRID SIZE COMPARISON PLOTS")

        # Find all depths that have data across multiple fractals
        all_depths = set()
        for fractal_data in all_fractal_data.values():
            all_depths.update(fractal_data['depth_results'].keys())

        for depth in sorted(all_depths):
            # Check if at least 2 fractals have non-timeout data at this depth
            fractals_with_data = 0
            for fractal_data in all_fractal_data.values():
                if depth in fractal_data['depth_results']:
                    depth_data = fractal_data['depth_results'][depth]
                    has_valid = any(not result.get('timed_out', False)
                                   for result in depth_data['grid_results'].values())
                    if has_valid:
                        fractals_with_data += 1

            if fractals_with_data >= 2:
                print(f"\n  Creating grid comparison plot for depth {depth}...")
                try:
                    grid_comp_plot = plot_grid_comparison_at_depth(
                        all_fractal_data, depth, GRID_COMPARISON_PLOTS_DIR
                    )
                    all_plot_files.append(grid_comp_plot)
                    print(f"    ✓ Grid comparison plot saved: {os.path.basename(grid_comp_plot)}")
                except Exception as e:
                    print(f"    ✗ Grid comparison plot error: {e}")

    # Final summary
    total_time = time.time() - total_start
    print_header("VERIFICATION COMPLETE")
    print(f"Total time: {format_time(total_time)}")
    print(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    print(f"\n✓ Generated {len(all_csv_files)} CSV files:")
    for csv_file in all_csv_files:
        print(f"  - {csv_file}")

    if ENABLE_PLOTTING and all_plot_files:
        print(f"\n✓ Generated {len(all_plot_files)} plot files:")
        for plot_file in all_plot_files[:10]:
            print(f"  - {plot_file}")
        if len(all_plot_files) > 10:
            print(f"  ... and {len(all_plot_files) - 10} more")

    print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Verification interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()