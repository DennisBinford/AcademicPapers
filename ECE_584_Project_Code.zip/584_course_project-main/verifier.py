from z3 import Solver, Real, And, sat, Or, Not
import time
from collections import defaultdict


class TimeoutException(Exception):
    """Exception raised when verification times out."""
    pass


def timeout_handler(signum, frame):
    """Signal handler for timeout."""
    raise TimeoutException("Verification timed out")


class SpatialIndex:
    """Spatial index using grid-based hashing to reduce pair-wise comparisons."""

    def __init__(self, segments, grid_size=10):
        self.grid_size = grid_size
        self.cells = defaultdict(list)

        # Calculate bounds
        all_coords = []
        for seg in segments:
            all_coords.extend([
                (seg.start.concrete_x, seg.start.concrete_y),
                (seg.end.concrete_x, seg.end.concrete_y)
            ])

        xs = [c[0] for c in all_coords]
        ys = [c[1] for c in all_coords]

        self.min_x, self.max_x = min(xs), max(xs)
        self.min_y, self.max_y = min(ys), max(ys)

        # Add small margin
        margin_x = (self.max_x - self.min_x) * 0.01
        margin_y = (self.max_y - self.min_y) * 0.01
        self.min_x -= margin_x
        self.max_x += margin_x
        self.min_y -= margin_y
        self.max_y += margin_y

        self.cell_width = (self.max_x - self.min_x) / grid_size
        self.cell_height = (self.max_y - self.min_y) / grid_size

        # Assign segments to cells
        for idx, seg in enumerate(segments):
            cells = self._get_segment_cells(seg)
            for cell in cells:
                self.cells[cell].append(idx)

    def _get_cell(self, x, y):
        """Get grid cell for a point."""
        if self.cell_width == 0 or self.cell_height == 0:
            return (0, 0)

        cell_x = int((x - self.min_x) / self.cell_width)
        cell_y = int((y - self.min_y) / self.cell_height)

        cell_x = max(0, min(self.grid_size - 1, cell_x))
        cell_y = max(0, min(self.grid_size - 1, cell_y))

        return (cell_x, cell_y)

    def _get_segment_cells(self, seg):
        """Get all cells that a segment intersects."""
        cells = set()
        num_samples = 10
        for i in range(num_samples + 1):
            t = i / num_samples
            x = seg.start.concrete_x + t * (seg.end.concrete_x - seg.start.concrete_x)
            y = seg.start.concrete_y + t * (seg.end.concrete_y - seg.start.concrete_y)
            cells.add(self._get_cell(x, y))
        return cells

    def get_candidate_pairs(self, segments):
        """Get candidate segment pairs that might interact."""
        candidates = set()
        for cell, indices in self.cells.items():
            for i in range(len(indices)):
                for j in range(i + 1, len(indices)):
                    idx1, idx2 = indices[i], indices[j]
                    if idx1 > idx2:
                        idx1, idx2 = idx2, idx1
                    candidates.add((idx1, idx2))
        return candidates


class BoundingBox:
    """Axis-aligned bounding box for fast intersection pre-check."""

    def __init__(self, seg):
        self.min_x = min(seg.start.concrete_x, seg.end.concrete_x)
        self.max_x = max(seg.start.concrete_x, seg.end.concrete_x)
        self.min_y = min(seg.start.concrete_y, seg.end.concrete_y)
        self.max_y = max(seg.start.concrete_y, seg.end.concrete_y)

    def intersects(self, other):
        """Check if this bounding box intersects another."""
        return not (self.max_x < other.min_x or other.max_x < self.min_x or
                    self.max_y < other.min_y or other.max_y < self.min_y)


class FractalVerifier:
    """Verifies self-avoiding property of fractals using Z3."""

    def __init__(self, use_spatial_index=True, use_bounding_boxes=True, grid_size=10, timeout_per_pair=1.0):
        self.use_spatial_index = use_spatial_index
        self.use_bounding_boxes = use_bounding_boxes
        self.grid_size = grid_size
        self.timeout_per_pair = timeout_per_pair  # Timeout for individual Z3 solver calls
        self.timing_info = {}

    def segments_violate_self_avoidance(self, seg1, seg2, i, j):
        """
        Check if two segments violate the self-avoiding property using Z3.

        Two segments violate self-avoidance if:
        1. They cross at interior points (proper crossing)
        2. They overlap (collinear overlap or perfect overlap)
        3. They touch at endpoints (when not adjacent)

        Adjacent segments (|i-j| == 1) are allowed to share one endpoint.

        Returns:
            bool: True if segments violate self-avoidance, False otherwise
        """
        solver = Solver()

        # Set timeout for Z3 solver (in milliseconds)
        solver.set("timeout", int(self.timeout_per_pair * 1000))

        # Segment 1 endpoints
        x1 = Real('x1')
        y1 = Real('y1')
        x2 = Real('x2')
        y2 = Real('y2')

        # Segment 2 endpoints
        x3 = Real('x3')
        y3 = Real('y3')
        x4 = Real('x4')
        y4 = Real('y4')

        # Add constraints for concrete values
        solver.add(x1 == seg1.start.concrete_x)
        solver.add(y1 == seg1.start.concrete_y)
        solver.add(x2 == seg1.end.concrete_x)
        solver.add(y2 == seg1.end.concrete_y)
        solver.add(x3 == seg2.start.concrete_x)
        solver.add(y3 == seg2.start.concrete_y)
        solver.add(x4 == seg2.end.concrete_x)
        solver.add(y4 == seg2.end.concrete_y)

        # Parameters for intersection
        t = Real('t')
        u = Real('u')

        # Intersection equations: seg1(t) = seg2(u)
        # x1 + t*(x2-x1) = x3 + u*(x4-x3)
        # y1 + t*(y2-y1) = y3 + u*(y4-y3)
        eq_x = x1 + t * (x2 - x1) == x3 + u * (x4 - x3)
        eq_y = y1 + t * (y2 - y1) == y3 + u * (y4 - y3)

        # Check for any intersection (interior or endpoint)
        # t, u in [0, 1] means intersection exists
        intersection_exists = And(
            eq_x, eq_y,
            t >= 0, t <= 1,
            u >= 0, u <= 1
        )

        # If segments are adjacent, they should share exactly one endpoint
        # This is allowed and doesn't violate self-avoidance
        if abs(i - j) == 1:
            # Adjacent segments can only share one endpoint (t=0 or 1, u=0 or 1)
            # This is the normal connection point
            endpoint_only = Or(
                And(t == 0, u == 0),  # start1 == start2
                And(t == 0, u == 1),  # start1 == end2
                And(t == 1, u == 0),  # end1 == start2
                And(t == 1, u == 1)  # end1 == end2
            )

            # Violation only if intersection exists but is NOT just endpoint
            solver.add(And(intersection_exists, Not(endpoint_only)))
        else:
            # Non-adjacent segments: any intersection is a violation
            solver.add(intersection_exists)

        # Check if violation exists
        try:
            result = solver.check()
            return result == sat
        except Exception:
            # If Z3 times out or errors, assume no violation to be safe
            # (This prevents false positives but might miss some violations)
            return False

    def check_self_avoidance(self, z3_segments, global_timeout=None):
        """
        Check self-avoidance property for all segment pairs.

        Args:
            z3_segments: List of segment objects to verify
            global_timeout: Optional overall timeout in seconds (None = no timeout)
        """
        start_time = time.time()
        global_start = start_time

        violations = []

        # Setup optimization structures
        bboxes = None
        if self.use_bounding_boxes:
            bboxes = [BoundingBox(seg) for seg in z3_segments]

        spatial_index = None
        candidate_pairs = None
        if self.use_spatial_index:
            spatial_index = SpatialIndex(z3_segments, grid_size=self.grid_size)
            candidate_pairs = spatial_index.get_candidate_pairs(z3_segments)

        pairs_checked = 0
        pairs_skipped = 0

        try:
            # Check all segment pairs
            for i in range(len(z3_segments)):
                # Check global timeout periodically
                if global_timeout is not None:
                    elapsed = time.time() - global_start
                    if elapsed > global_timeout:
                        raise TimeoutException(f"Global timeout exceeded: {elapsed:.2f}s > {global_timeout}s")

                for j in range(i + 1, len(z3_segments)):
                    # Skip adjacent segments entirely - they're allowed to share endpoints
                    if abs(i - j) == 1:
                        continue

                    # Skip pairs filtered by spatial index
                    if candidate_pairs is not None and (i, j) not in candidate_pairs:
                        pairs_skipped += 1
                        continue

                    # Skip pairs with non-intersecting bounding boxes
                    if bboxes is not None and not bboxes[i].intersects(bboxes[j]):
                        pairs_skipped += 1
                        continue

                    seg1 = z3_segments[i]
                    seg2 = z3_segments[j]

                    # Check if this pair violates self-avoidance
                    try:
                        if self.segments_violate_self_avoidance(seg1, seg2, i, j):
                            violations.append((i, j))
                    except Exception:
                        # If individual solver fails, skip this pair
                        pass

                    pairs_checked += 1
        except TimeoutException:
            # Re-raise timeout to be handled by caller
            raise
        finally:
            # Always record timing info
            total_time = time.time() - start_time
            self.timing_info = {
                "total_time": total_time,
                "pairs_checked": pairs_checked,
                "pairs_skipped": pairs_skipped,
                "optimization_ratio": pairs_skipped / (pairs_checked + pairs_skipped)
                if (pairs_checked + pairs_skipped) > 0 else 0
            }

        return violations

    def is_self_avoiding(self, z3_segments, global_timeout=None):
        """
        Check if the fractal is completely self-avoiding.

        Args:
            z3_segments: List of segment objects to verify
            global_timeout: Optional overall timeout in seconds (None = no timeout)

        Returns:
            is_avoiding (bool): True if no violations found
            violations (list): List of (i, j) segment index pairs that violate self-avoidance
        """
        violations = self.check_self_avoidance(z3_segments, global_timeout)
        is_avoiding = len(violations) == 0

        return is_avoiding, violations

    def get_timing_info(self):
        """Get timing and optimization statistics."""
        return self.timing_info