import os, csv, time, datetime
from datetime import datetime as dt
from fractal_generators import FractalGenerator
from verifier import FractalVerifier, TimeoutException
import matplotlib.pyplot as plt
import signal

# Global flag for timeout
_timeout_flag = False
_verification_active = False


def timeout_handler(signum, frame):
    """Signal handler for timeout."""
    global _timeout_flag, _verification_active
    _timeout_flag = True
    # Only raise if we're actively verifying, not during cleanup
    if _verification_active:
        raise TimeoutException("Verification timed out")


def format_time(seconds):
    """Format time in appropriate units (μs, ms, or s)."""
    if seconds < 0.001:
        return f"{seconds * 1000000:.2f}μs"
    elif seconds < 1:
        return f"{seconds * 1000:.2f}ms"
    else:
        return f"{seconds:.2f}s"


def get_timestamp():
    """Get formatted timestamp for logging."""
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def print_header(title, width=70):
    """Print a formatted header."""
    print(f"\n{'=' * width}")
    print(title.center(width))
    print(f"{'=' * width}")


def calculate_memory_usage(segments):
    num_segments = len(segments)
    base_memory_bytes = num_segments * 4 * 8
    python_overhead = num_segments * 100
    total_bytes = base_memory_bytes + python_overhead

    return {
        'segments': num_segments,
        'base_bytes': base_memory_bytes,
        'overhead_bytes': python_overhead,
        'total_bytes': total_bytes,
        'total_kb': total_bytes / 1024,
        'total_mb': total_bytes / (1024 * 1024)
    }


def verify_with_grid_size(segments, grid_size, timeout_seconds=300):
    """Verify segments with timeout support."""
    global _timeout_flag, _verification_active
    _timeout_flag = False
    _verification_active = False

    generator = FractalGenerator()
    z3_segments = generator.segments_to_z3(segments)

    # Configure verifier with per-pair timeout (Z3 solver timeout)
    # Use 1 second per pair by default
    timeout_per_pair = 1.0

    if grid_size == -1:
        verifier = FractalVerifier(use_spatial_index=False, use_bounding_boxes=False,
                                   timeout_per_pair=timeout_per_pair)
    elif grid_size == 0:
        verifier = FractalVerifier(use_spatial_index=False, use_bounding_boxes=True,
                                   timeout_per_pair=timeout_per_pair)
    else:
        verifier = FractalVerifier(use_spatial_index=True, use_bounding_boxes=True,
                                   grid_size=grid_size, timeout_per_pair=timeout_per_pair)

    start_time = time.time()
    timed_out = False
    is_avoiding = False
    violations = []
    alarm_set = False

    try:
        # Set up signal-based timeout for Unix-like systems
        if hasattr(signal, 'SIGALRM'):
            old_handler = signal.signal(signal.SIGALRM, timeout_handler)
            signal.alarm(timeout_seconds)
            alarm_set = True

        # Mark that we're actively verifying
        _verification_active = True

        # Pass global timeout to verifier for periodic checking
        is_avoiding, violations = verifier.is_self_avoiding(z3_segments, global_timeout=timeout_seconds)
        verify_time = time.time() - start_time

    except TimeoutException:
        verify_time = time.time() - start_time
        if verify_time > timeout_seconds:
            verify_time = timeout_seconds
        timed_out = True
    except Exception as e:
        # Treat ANY exception as a timeout if it's timeout-related or near timeout threshold
        # NEVER re-raise - always return a result dict
        verify_time = time.time() - start_time
        error_msg = str(e).lower()

        # Check if it's clearly a timeout
        if ('timeout' in error_msg or
                'timed out' in error_msg or
                verify_time >= timeout_seconds * 0.9):
            # Treat as timeout
            if verify_time > timeout_seconds:
                verify_time = timeout_seconds
            timed_out = True
        else:
            # Even for other errors, if we're close to timeout, treat as timeout
            # Otherwise, it's a genuine error but we still don't raise - just mark it
            if verify_time >= timeout_seconds * 0.8:
                timed_out = True
                if verify_time > timeout_seconds:
                    verify_time = timeout_seconds
            else:
                # Genuine error - still return a result but mark as failed
                timed_out = True  # Mark as timeout to exclude from results
                print(f"\n    Warning: Unexpected error during verification: {e}")
    finally:
        # Mark that we're no longer actively verifying
        _verification_active = False

        # Always cancel the alarm and restore handler
        if alarm_set and hasattr(signal, 'SIGALRM'):
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)

    # Get timing info if available
    if not timed_out and hasattr(verifier, 'timing_info'):
        timing = verifier.get_timing_info()
    else:
        timing = {'pairs_checked': 0, 'pairs_skipped': 0, 'optimization_ratio': 0}

    return {
        'grid_size': grid_size,
        'verify_time': verify_time,
        'is_avoiding': is_avoiding,
        'violations': violations,
        'num_violations': len(violations),
        'pairs_checked': timing['pairs_checked'],
        'pairs_skipped': timing['pairs_skipped'],
        'optimization_ratio': timing['optimization_ratio'],
        'timed_out': timed_out
    }


def save_results_to_csv(fractal_key, fractal_name, all_depth_results, results_dir):
    """Save results to CSV, excluding timed out entries."""
    timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
    filename = os.path.join(results_dir, f'{fractal_key}_results_{timestamp}.csv')

    fieldnames = ['depth', 'num_segments', 'memory_bytes', 'memory_kb', 'memory_mb', 'grid_size',
                  'verify_time_sec', 'verify_time_ms', 'speedup_vs_slowest', 'pairs_checked',
                  'pairs_skipped', 'optimization_ratio', 'is_self_avoiding', 'num_violations']

    with open(filename, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for depth in sorted(all_depth_results.keys()):
            depth_data = all_depth_results[depth]
            num_segments = depth_data['num_segments']
            memory_info = depth_data['memory']

            # Filter out timed out results
            valid_results = {gs: result for gs, result in depth_data['grid_results'].items()
                             if not result.get('timed_out', False)}

            if not valid_results:
                continue  # Skip this depth entirely if all results timed out

            slowest_time = max(result['verify_time'] for result in valid_results.values())

            for grid_size in sorted(valid_results.keys()):
                result = valid_results[grid_size]
                speedup = slowest_time / result['verify_time'] if slowest_time > 0 and result[
                    'verify_time'] > 0 else 1.0

                writer.writerow({
                    'depth': depth,
                    'num_segments': num_segments,
                    'memory_bytes': memory_info['total_bytes'],
                    'memory_kb': memory_info['total_kb'],
                    'memory_mb': memory_info['total_mb'],
                    'grid_size': grid_size,
                    'verify_time_sec': result['verify_time'],
                    'verify_time_ms': result['verify_time'] * 1000,
                    'speedup_vs_slowest': speedup,
                    'pairs_checked': result['pairs_checked'],
                    'pairs_skipped': result['pairs_skipped'],
                    'optimization_ratio': result['optimization_ratio'],
                    'is_self_avoiding': result['is_avoiding'],
                    'num_violations': result['num_violations']
                })

    print(f"  💾 Results saved to: {filename}")
    return filename


def print_depth_summary(fractal_name, depth, num_segments, memory_mb, grid_results):
    """Print a summary for one depth with all grid sizes, excluding timeouts."""
    print(f"\n  Depth {depth}: {num_segments:,} segments, {memory_mb:.2f} MB")

    # Filter out timed out results
    valid_results = {gs: result for gs, result in grid_results.items()
                     if not result.get('timed_out', False)}

    if not valid_results:
        print(f"  All grid sizes timed out - no summary available")
        return

    print(f"  {'Grid':<15} {'Time':<12} {'Speedup':<10} {'Pairs Checked':<15} "
          f"{'Pairs Skipped':<15} {'Opt Ratio':<12} {'Result':<20}")
    print(f"  {'-' * 110}")

    slowest_time = max(result['verify_time'] for result in valid_results.values())

    for grid_size in sorted(valid_results.keys()):
        result = valid_results[grid_size]
        grid_str = "-1 (Raw Z3)" if grid_size == -1 else "0 (BB only)" if grid_size == 0 else f"{grid_size}x{grid_size}"
        time_str = format_time(result['verify_time'])

        speedup = slowest_time / result['verify_time'] if slowest_time > 0 and result['verify_time'] > 0 else 1.0
        speedup_str = f"{speedup:.2f}x"

        # Status: avoiding or violations
        if result['is_avoiding']:
            status = "✓ Avoiding"
        else:
            status = f"✗ {result['num_violations']} violations"

        print(f"  {grid_str:<15} {time_str:<12} {speedup_str:<10} "
              f"{result['pairs_checked']:<15,} {result['pairs_skipped']:<15,} "
              f"{result['optimization_ratio']:.2%}{'':<6} {status:<20}")


def save_results_to_csv(fractal_key, fractal_name, all_depth_results, results_dir):
    timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
    filename = os.path.join(results_dir, f'{fractal_key}_results_{timestamp}.csv')

    fieldnames = ['depth', 'num_segments', 'memory_bytes', 'memory_kb', 'memory_mb', 'grid_size',
                  'verify_time_sec', 'verify_time_ms', 'speedup_vs_slowest', 'pairs_checked',
                  'pairs_skipped', 'optimization_ratio', 'is_self_avoiding', 'num_violations', 'timed_out']

    with open(filename, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for depth in sorted(all_depth_results.keys()):
            depth_data = all_depth_results[depth]
            num_segments = depth_data['num_segments']
            memory_info = depth_data['memory']
            slowest_time = max(result['verify_time'] for result in depth_data['grid_results'].values())

            for grid_size in sorted(depth_data['grid_results'].keys()):
                result = depth_data['grid_results'][grid_size]
                speedup = slowest_time / result['verify_time'] if slowest_time > 0 and result[
                    'verify_time'] > 0 else 1.0

                writer.writerow({
                    'depth': depth,
                    'num_segments': num_segments,
                    'memory_bytes': memory_info['total_bytes'],
                    'memory_kb': memory_info['total_kb'],
                    'memory_mb': memory_info['total_mb'],
                    'grid_size': grid_size,
                    'verify_time_sec': result['verify_time'],
                    'verify_time_ms': result['verify_time'] * 1000,
                    'speedup_vs_slowest': speedup,
                    'pairs_checked': result['pairs_checked'],
                    'pairs_skipped': result['pairs_skipped'],
                    'optimization_ratio': result['optimization_ratio'],
                    'is_self_avoiding': result['is_avoiding'],
                    'num_violations': result['num_violations'],
                    'timed_out': result.get('timed_out', False)
                })

    print(f"  💾 Results saved to: {filename}")
    return filename


def print_depth_summary(fractal_name, depth, num_segments, memory_mb, grid_results):
    """Print a summary for one depth with all grid sizes."""
    print(f"\n  Depth {depth}: {num_segments:,} segments, {memory_mb:.2f} MB")
    print(f"  {'Grid':<15} {'Time':<12} {'Speedup':<10} {'Pairs Checked':<15} "
          f"{'Pairs Skipped':<15} {'Opt Ratio':<12} {'Result':<20}")
    print(f"  {'-' * 110}")

    slowest_time = max(result['verify_time'] for result in grid_results.values())

    for grid_size in sorted(grid_results.keys()):
        result = grid_results[grid_size]
        grid_str = "-1 (Raw Z3)" if grid_size == -1 else "0 (BB only)" if grid_size == 0 else f"{grid_size}x{grid_size}"
        time_str = format_time(result['verify_time'])
        if result.get('timed_out', False):
            time_str += " (TIMEOUT)"

        speedup = slowest_time / result['verify_time'] if slowest_time > 0 and result['verify_time'] > 0 else 1.0
        speedup_str = f"{speedup:.2f}x"

        # Status priority: timeout > avoiding > violations
        if result.get('timed_out', False):
            status = "⏱️ TIMEOUT"
        elif result['is_avoiding']:
            status = "✓ Avoiding"
        else:
            status = f"✗ {result['num_violations']} violations"

        print(f"  {grid_str:<15} {time_str:<12} {speedup_str:<10} "
              f"{result['pairs_checked']:<15,} {result['pairs_skipped']:<15,} "
              f"{result['optimization_ratio']:.2%}{'':<6} {status:<20}")


def plot_fractal_comparison_at_grid_size(all_fractal_data, grid_size, output_dir="comparison_plots"):
    """Create comparison plot for all fractals at specific grid size."""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    fig, ax = plt.subplots(figsize=(12, 7))
    colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#6A994E', '#BC4B51']
    markers = ['o', 's', '^', 'D', 'v', 'p']

    for idx, (fractal_key, data) in enumerate(sorted(all_fractal_data.items())):
        fractal_name = data['name']
        all_depth_results = data['depth_results']
        depths, times_ms = [], []

        for depth in sorted(all_depth_results.keys()):
            if grid_size in all_depth_results[depth]['grid_results']:
                result = all_depth_results[depth]['grid_results'][grid_size]
                if not result.get('timed_out', False):
                    depths.append(depth)
                    times_ms.append(result['verify_time'] * 1000)

        if depths:
            ax.plot(depths, times_ms, marker=markers[idx % len(markers)], markersize=8,
                    linewidth=2.5, label=fractal_name, color=colors[idx % len(colors)])

    ax.set_xlabel('Depth', fontsize=12, fontweight='bold')
    ax.set_ylabel('Verification Time (ms)', fontsize=12, fontweight='bold')
    ax.legend(loc='best', fontsize=10, framealpha=0.9)
    ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.8)

    grid_str = "Raw Z3" if grid_size == -1 else "Bounding Box Only" if grid_size == 0 else f"{grid_size}×{grid_size} Grid"
    ax.set_title(f"Fractal Comparison\n{grid_str}", fontsize=14, fontweight='bold', pad=15)

    if times_ms and max(times_ms) / min([t for t in times_ms if t > 0]) > 10:
        ax.set_yscale('log')

    plt.tight_layout()

    timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
    filename = os.path.join(output_dir, f"fractal_comparison_g{grid_size}_{timestamp}.png")
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()

    return filename