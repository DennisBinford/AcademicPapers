import os
import matplotlib.pyplot as plt
from datetime import datetime as dt
from matplotlib.lines import Line2D


def plot_single_grid_visualization(segments, violations, fractal_name, depth,
                                   grid_size, verify_time, output_dir="plots"):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    plt.figure(figsize=(12, 10))

    violation_indices = set()
    if violations:
        for i, j in violations:
            violation_indices.add(i)
            violation_indices.add(j)

    for idx, (start, end) in enumerate(segments):
        x_coords = [start[0], end[0]]
        y_coords = [start[1], end[1]]

        if idx in violation_indices:
            plt.plot(x_coords, y_coords, 'r-', linewidth=2.0, alpha=0.8, zorder=2)
        else:
            plt.plot(x_coords, y_coords, 'b-', linewidth=0.5, alpha=0.6, zorder=1)

    if violations:
        for i, j in violations:
            seg_i, seg_j = segments[i], segments[j]
            mid_i = ((seg_i[0][0] + seg_i[1][0]) / 2, (seg_i[0][1] + seg_i[1][1]) / 2)
            mid_j = ((seg_j[0][0] + seg_j[1][0]) / 2, (seg_j[0][1] + seg_j[1][1]) / 2)
            plt.plot(mid_i[0], mid_i[1], 'ro', markersize=8, zorder=3)
            plt.plot(mid_j[0], mid_j[1], 'ro', markersize=8, zorder=3)

    plt.xlabel('X', fontsize=12)
    plt.ylabel('Y', fontsize=12)

    grid_str = f"{grid_size}×{grid_size}" if grid_size > 0 else "BB only" if grid_size == 0 else "Raw Z3"
    title = f"{fractal_name}\nDepth {depth}\nGrid: {grid_str} | Time: {format_time(verify_time)}"
    plt.title(title, fontsize=14, fontweight='bold')

    plt.axis('equal')
    plt.grid(True, alpha=0.3)

    if violations:
        legend_elements = [
            Line2D([0], [0], color='b', linewidth=1, label='Normal segments'),
            Line2D([0], [0], color='r', linewidth=2, label='Violating segments'),
            Line2D([0], [0], marker='o', color='w', markerfacecolor='r', markersize=8, label='Violation markers')
        ]
        plt.legend(handles=legend_elements, loc='best')

    plt.tight_layout()

    timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
    safe_name = fractal_name.replace(' ', '_').replace('é', 'e').replace('ń', 'n')
    filename = os.path.join(output_dir, f"{safe_name}_d{depth}_g{grid_size}_{timestamp}.png")
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()

    return filename


def plot_verification_times_for_depth(fractal_name, depth, grid_results, output_dir="verification_time_plots"):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    grid_sizes = sorted(grid_results.keys())
    times_ms = [grid_results[gs]['verify_time'] * 1000 for gs in grid_sizes]

    labels = []
    for gs in grid_sizes:
        if gs == -1:
            labels.append('Raw Z3')
        elif gs == 0:
            labels.append('BB only')
        else:
            labels.append(f'{gs}×{gs}')

    fig, ax = plt.subplots(figsize=(10, 6))

    ax.plot(range(len(grid_sizes)), times_ms, marker='o', markersize=10, linewidth=2.5,
            color='#2E86AB', markerfacecolor='#A23B72', markeredgecolor='#2E86AB', markeredgewidth=2)

    ax.set_xticks(range(len(grid_sizes)))
    ax.set_xticklabels(labels, fontsize=11)
    ax.set_ylabel('Verification Time (ms)', fontsize=12, fontweight='bold')
    ax.set_xlabel('Grid Configuration', fontsize=12, fontweight='bold')

    title = f"{fractal_name}\nDepth {depth}"
    ax.set_title(title, fontsize=14, fontweight='bold', pad=15)

    ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.8)
    ax.set_axisbelow(True)

    if max(times_ms) / min([t for t in times_ms if t > 0]) > 10:
        ax.set_yscale('log')

    plt.tight_layout()

    timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
    safe_name = fractal_name.replace(' ', '_').replace('é', 'e').replace('ń', 'n')
    filename = os.path.join(output_dir, f"{safe_name}_d{depth}_verification_times_{timestamp}.png")
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()

    return filename


def plot_verification_times_vs_depth(fractal_name, all_depth_results, output_dir="depth_scaling_plots"):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    first_depth = min(all_depth_results.keys())
    grid_sizes = sorted(all_depth_results[first_depth]['grid_results'].keys())

    plot_files = []

    for grid_size in grid_sizes:
        depths = sorted(all_depth_results.keys())
        times_ms = []

        for depth in depths:
            result = all_depth_results[depth]['grid_results'][grid_size]
            times_ms.append(result['verify_time'] * 1000)

        fig, ax = plt.subplots(figsize=(10, 6))

        ax.plot(depths, times_ms, marker='o', markersize=10, linewidth=2.5,
                color='#2E86AB', markerfacecolor='#A23B72', markeredgecolor='#2E86AB', markeredgewidth=2)

        ax.set_xlabel('Depth', fontsize=12, fontweight='bold')
        ax.set_ylabel('Verification Time (ms)', fontsize=12, fontweight='bold')
        ax.set_xticks(depths)
        ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.8)
        ax.set_axisbelow(True)

        if len(times_ms) > 1 and max(times_ms) / min([t for t in times_ms if t > 0]) > 10:
            ax.set_yscale('log')
            ax.set_ylabel('Verification Time (ms, log scale)', fontsize=12, fontweight='bold')

        grid_str = "Raw Z3 (No Optimizations)" if grid_size == -1 else "Bounding Box Only" if grid_size == 0 else f"{grid_size}×{grid_size} Grid"
        ax.set_title(f"{fractal_name}\n{grid_str}", fontsize=14, fontweight='bold', pad=15)

        plt.tight_layout()

        timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
        safe_name = fractal_name.replace(' ', '_').replace('é', 'e').replace('ń', 'n')
        filename = os.path.join(output_dir, f"{safe_name}_g{grid_size}_depth_scaling_{timestamp}.png")
        plt.savefig(filename, dpi=150, bbox_inches='tight')
        plt.close()

        plot_files.append(filename)

    return plot_files


def plot_segment_count_vs_depth(fractal_name, all_depth_results, output_dir="segment_scaling_plots"):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    depths = sorted(all_depth_results.keys())
    num_segments = [all_depth_results[depth]['num_segments'] for depth in depths]

    fig, ax = plt.subplots(figsize=(10, 6))

    ax.plot(depths, num_segments, marker='s', markersize=10, linewidth=2.5,
            color='#F18F01', markerfacecolor='#C73E1D', markeredgecolor='#F18F01', markeredgewidth=2)

    ax.set_xlabel('Depth', fontsize=12, fontweight='bold')
    ax.set_ylabel('Number of Segments', fontsize=12, fontweight='bold')
    ax.set_xticks(depths)
    ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.8)
    ax.set_axisbelow(True)

    if len(num_segments) > 1 and max(num_segments) / min([s for s in num_segments if s > 0]) > 10:
        ax.set_yscale('log')
        ax.set_ylabel('Number of Segments (log scale)', fontsize=12, fontweight='bold')

    ax.ticklabel_format(style='plain', axis='y')
    ax.set_title(f"{fractal_name}", fontsize=14, fontweight='bold', pad=15)

    plt.tight_layout()

    timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
    safe_name = fractal_name.replace(' ', '_').replace('é', 'e').replace('ń', 'n')
    filename = os.path.join(output_dir, f"{safe_name}_segment_scaling_{timestamp}.png")
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()

    return filename


def plot_grid_comparison_at_depth(all_fractal_data, depth, output_dir="grid_comparison_plots"):
    """Create comparison plot showing all fractals across different grid sizes at a specific depth."""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    fig, ax = plt.subplots(figsize=(12, 7))
    colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#6A994E', '#BC4B51']
    markers = ['o', 's', '^', 'D', 'v', 'p']

    for idx, (fractal_key, data) in enumerate(sorted(all_fractal_data.items())):
        fractal_name = data['name']
        all_depth_results = data['depth_results']

        # Check if this fractal has data for this depth
        if depth not in all_depth_results:
            continue

        grid_sizes = []
        times_ms = []

        depth_data = all_depth_results[depth]
        for grid_size in sorted(depth_data['grid_results'].keys()):
            result = depth_data['grid_results'][grid_size]
            if not result.get('timed_out', False):
                grid_sizes.append(grid_size)
                times_ms.append(result['verify_time'] * 1000)

        if grid_sizes:
            ax.plot(grid_sizes, times_ms, marker=markers[idx % len(markers)], markersize=8,
                    linewidth=2.5, label=fractal_name, color=colors[idx % len(colors)])

    ax.set_xlabel('Grid Size', fontsize=12, fontweight='bold')
    ax.set_ylabel('Verification Time (ms)', fontsize=12, fontweight='bold')
    ax.legend(loc='best', fontsize=10, framealpha=0.9)
    ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.8)

    ax.set_title(f"Grid Size Performance Comparison\nDepth {depth}",
                 fontsize=14, fontweight='bold', pad=15)

    if times_ms and max(times_ms) / min([t for t in times_ms if t > 0]) > 10:
        ax.set_yscale('log')
        ax.set_ylabel('Verification Time (ms, log scale)', fontsize=12, fontweight='bold')

    plt.tight_layout()

    timestamp = dt.now().strftime('%Y%m%d_%H%M%S')
    filename = os.path.join(output_dir, f"grid_comparison_d{depth}_{timestamp}.png")
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()

    return filename


def format_time(seconds):
    """Format time in appropriate units."""
    if seconds < 0.001:
        return f"{seconds * 1000000:.2f}μs"
    elif seconds < 1:
        return f"{seconds * 1000:.2f}ms"
    else:
        return f"{seconds:.2f}s"