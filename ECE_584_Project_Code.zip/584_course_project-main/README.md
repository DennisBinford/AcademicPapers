# Fractal Self-Avoidance Verification

A comprehensive tool for verifying the self-avoiding property of fractal curves using Z3 theorem proving with spatial optimization techniques. This project generates various fractal curves, verifies whether they cross themselves, and produces detailed performance analysis and visualizations.

## Overview

This tool verifies whether fractal curves are **self-avoiding** (meaning they don't cross or overlap themselves) by:
- Generating fractal curves at various depth levels
- Using Z3 theorem prover to formally verify intersection properties
- Applying spatial indexing and bounding box optimizations to improve performance
- Generating detailed performance metrics, CSV reports, and visualization plots
- Creating heatmaps to visualize spatial index distribution

## File Structure

### Core Files

**`fractal_generators.py`**
- Generates six types of fractal curves: Koch Curve, Heighway Dragon, Lévy C Curve, Hilbert Curve, Sierpiński Arrowhead, and Gosper Curve
- Implements recursive and L-system algorithms for fractal generation
- Converts fractal segments to Z3 symbolic representations

**`geometry.py`**
- Defines `Point` and `Segment` classes with Z3 symbolic variables
- Provides the geometric primitives used by the Z3 verifier

**`verifier.py`**
- Core verification engine using Z3 theorem prover
- Implements three verification strategies:
  - Raw Z3 (no optimizations)
  - Bounding box filtering
  - Spatial grid indexing
- Checks for segment intersections, overlaps, and improper endpoint contacts
- Handles timeouts for long-running verifications

**`helper.py`**
- Helper functions for verification workflow
- Manages timeouts and error handling
- Calculates memory usage
- Formats timing output
- Saves results to CSV files
- Generates cross-fractal comparison plots

**`helper_plotting.py`**
- Plotting utilities for visualization
- Creates fractal visualizations with violation highlighting
- Generates performance comparison plots
- Produces depth scaling and segment scaling plots

**`main.py`**
- Main program entry point
- Configurable verification pipeline
- Processes multiple fractals at multiple depths
- Tests various spatial optimization strategies
- Generates comprehensive CSV reports and plots

**`visualize_spatial_index.py`**
- Creates heatmaps showing segment distribution across spatial index grids
- Visualizes how different grid sizes affect segment grouping
- Generates individual heatmaps and multi-grid comparison plots
- Produces statistics on grid cell occupancy

## Dependencies

```bash
pip install z3-solver numpy matplotlib
```

- **z3-solver**: Theorem prover for formal verification
- **numpy**: Numerical computations for fractal generation
- **matplotlib**: Plotting and visualization

## Running main.py

### Quick Start

```bash
python main.py
```

This will run verification on all configured fractals with default settings.

### Configuration

Edit the configuration variables at the top of `main.py`:

#### Timeout Setting

```python
VERIFICATION_TIMEOUT = 120  # seconds per verification
```

Controls how long each verification can run before timing out.

#### Fractal Selection

```python
FRACTAL_CONFIG = {
    'koch': {
        'name': 'Koch Curve',
        'method': 'generate_koch_curve',
        'depths': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    },
    # ... more fractals
}
```

- **Enable/disable fractals**: Comment out or remove fractals you don't want to test
- **Adjust depths**: Modify the `depths` list to test different complexity levels
- Higher depths = more segments = longer verification times

#### Grid Sizes

```python
GRID_SIZES = [-1, 0, 1, 10, 100]
```

Controls which spatial optimization strategies to test:
- **-1**: Raw Z3 (no optimizations)
- **0**: Bounding box filtering only
- **N > 0**: Spatial grid indexing with NxN grid

#### Plotting Options

```python
ENABLE_PLOTTING = True                    # Master switch for all plots
ENABLE_INDIVIDUAL_GRID_PLOTS = False     # Per-grid visualizations
ENABLE_VERIFICATION_TIME_PLOTS = True    # Time comparison plots
ENABLE_DEPTH_SCALING_PLOTS = True        # Performance vs depth
ENABLE_SEGMENT_SCALING_PLOTS = True      # Segment count growth
ENABLE_COMPARISON_PLOTS = True           # Cross-fractal comparisons
ENABLE_GRID_COMPARISON_PLOTS = True      # Grid size comparisons
```

### Output

The program creates several output directories:

**`verification_results/`**
- CSV files with detailed performance metrics for each fractal
- Columns include: depth, segments, memory usage, grid size, verification time, speedup, pairs checked/skipped, optimization ratio, self-avoidance result

**`plots/`**
- Individual fractal visualizations
- Violations highlighted in red if found

**`verification_time_plots/`**
- Performance comparison across different grid sizes for each depth

**`depth_scaling_plots/`**
- Verification time vs fractal depth for each grid size

**`segment_scaling_plots/`**
- Segment count growth with depth

**`comparison_plots/`**
- Cross-fractal performance comparisons at specific grid sizes

**`grid_comparison_plots/`**
- Grid size performance comparisons at specific depths

### Interpreting Results

**Self-Avoidance Status:**
- ✓ Avoiding: Fractal doesn't cross itself
- ✗ N violations: Found N segment pairs that violate self-avoidance

**Performance Metrics:**
- **Pairs Checked**: Number of segment pairs verified with Z3
- **Pairs Skipped**: Segment pairs filtered by optimizations
- **Optimization Ratio**: Percentage of pairs skipped (higher = better)
- **Speedup**: Performance improvement vs slowest method

**Timeouts:**
- ⏱️ TIMEOUT: Verification exceeded time limit
- Timed out results are excluded from CSV output and summaries
- If a grid size times out, it's automatically skipped for higher depths

## Using visualize_spatial_index.py

This script generates heatmaps showing how fractal segments are distributed across spatial index grids.

### Configuration

Edit the configuration section in `visualize_spatial_index.py`:

```python
# Which fractals to visualize
FRACTALS_TO_VISUALIZE = ['koch', 'dragon', 'levy', 'hilbert', 'sierpinski', 'gosper']

# Specific depths for each fractal
FRACTAL_CONFIG = {
    'koch': {
        'name': 'Koch Curve',
        'method': 'generate_koch_curve',
        'depths': [5, 7, 9]  # Choose depths to visualize
    },
    # ... configure other fractals
}

# Grid sizes to compare
GRID_SIZES = [10, 50, 100]

# Output options
GENERATE_INDIVIDUAL_HEATMAPS = True  # One heatmap per grid size
GENERATE_COMPARISON_PLOTS = True     # Side-by-side grid comparisons
```

### Running

```bash
python visualize_spatial_index.py
```

### Output

**`heatmaps/`**
- Individual heatmaps for each fractal/depth/grid combination
- Multi-grid comparison plots showing different grid sizes side-by-side
- Color intensity shows segment density per grid cell
- Log scale used automatically for high variance distributions

**`heatmap_statistics_{timestamp}.csv`**
- Statistics on grid occupancy
- Average/min/max segments per cell
- Occupied vs total cells

### Interpreting Heatmaps

- **Bright areas**: High segment density (many segments in that grid cell)
- **Dark areas**: Low or no segments
- **Uniform distribution**: Good spatial index performance
- **Clustered distribution**: May benefit from different grid size
- Compare different grid sizes to find optimal spatial partitioning

## Workflow Example

1. **Start with a subset**: Test one fractal at low depths to verify setup
   ```python
   FRACTAL_CONFIG = {'koch': {..., 'depths': [1, 2, 3]}}
   GRID_SIZES = [0, 10]
   ```

2. **Analyze results**: Check CSV files and plots in output directories

3. **Generate heatmaps**: Use `visualize_spatial_index.py` to understand spatial distribution

4. **Optimize grid sizes**: Based on heatmaps, adjust `GRID_SIZES` for better performance

5. **Full run**: Enable all fractals and depths for comprehensive analysis

## Performance Tips

- **Lower depths first**: Test low depths before running expensive high-depth verifications
- **Reduce timeout**: If verifications consistently succeed quickly, lower `VERIFICATION_TIMEOUT`
- **Grid size tuning**: Use heatmaps to find optimal grid sizes for each fractal
- **Selective plotting**: Disable plots you don't need to speed up execution
- **Parallel processing**: Run different fractals in separate Python processes

## Research Applications

This tool is useful for:
- Formal verification of fractal properties
- Performance analysis of spatial indexing algorithms
- Comparative fractal geometry studies
- Optimization technique evaluation
- Educational demonstrations of theorem proving
