import numpy as np
from geometry import Point, Segment

class FractalGenerator:

    def __init__(self):
        self.segments = []

    def koch_iter(self, start, end, depth):
        if depth == 0:
            return [(start, end)]
        else:
            start = np.array(start)
            end = np.array(end)
            vec = (end - start) / 3.0

            p1 = start
            p2 = start + vec
            p4 = start + 2 * vec
            p5 = end

            angle = np.pi / 3
            vec_rot = np.array([
                np.cos(angle) * vec[0] - np.sin(angle) * vec[1],
                np.sin(angle) * vec[0] + np.cos(angle) * vec[1]
            ])
            p3 = p2 + vec_rot

            return (
                self.koch_iter(p1, p2, depth - 1) +
                self.koch_iter(p2, p3, depth - 1) +
                self.koch_iter(p3, p4, depth - 1) +
                self.koch_iter(p4, p5, depth - 1)
            )

    def generate_koch_curve(self, depth=3, start=(0, 0), end=(3, 0)):
        self.segments = self.koch_iter(start, end, depth)
        return self.segments

    def heighway_dragon(self, start, end, depth):
        def _dragon_recursive(a_pt, b_pt, d, sign):
            if d == 0:
                return [(tuple(a_pt), tuple(b_pt))]

            a = complex(a_pt[0], a_pt[1])
            b = complex(b_pt[0], b_pt[1])
            mul = complex(0.5, 0.5 * sign)
            mid = a + (b - a) * mul
            p = (mid.real, mid.imag)

            return (_dragon_recursive(a_pt, p, d - 1, 1) +
                    _dragon_recursive(p, b_pt, d - 1, -1))

        return _dragon_recursive(start, end, depth, 1)

    def generate_heighway_dragon(self, depth=10, start=(0, 0), end=(1, 0)):
        self.segments = self.heighway_dragon(start, end, depth)
        return self.segments

    def levy_C(self, start, end, depth):
        if depth == 0:
            return [(tuple(start), tuple(end))]
        else:
            a = complex(start[0], start[1])
            b = complex(end[0], end[1])
            mid = a + (b - a) * complex(0.5, 0.5)
            p = (mid.real, mid.imag)

            return (
                self.levy_C(start, p, depth - 1) +
                self.levy_C(p, end, depth - 1)
            )

    def generate_levy_curve(self, depth=10, start=(0, 0), end=(1, 0)):
        self.segments = self.levy_C(start, end, depth)
        return self.segments

    def hilbert_curve_lsystem(self, depth):
        def apply_rules(axiom, rules):
            result = ""
            for char in axiom:
                result += rules.get(char, char)
            return result

        rules = {
            'A': '+BF-AFA-FB+',
            'B': '-AF+BFB+FA-'
        }

        axiom = 'A'
        for _ in range(depth):
            axiom = apply_rules(axiom, rules)

        return axiom

    def generate_hilbert_curve(self, depth=4, size=10.0):
        lsystem_string = self.hilbert_curve_lsystem(depth)
        segments = []
        x, y = 0.0, 0.0
        direction = 0
        step = size / (2 ** depth - 1) if depth > 0 else size

        for char in lsystem_string:
            if char == 'F':
                new_x = x + step * (1 if direction == 0 else -1 if direction == 2 else 0)
                new_y = y + step * (1 if direction == 1 else -1 if direction == 3 else 0)
                segments.append(((x, y), (new_x, new_y)))
                x, y = new_x, new_y
            elif char == '+':
                direction = (direction + 1) % 4
            elif char == '-':
                direction = (direction - 1) % 4

        self.segments = segments
        return segments

    def sierpinski_arrowhead_lsystem(self, depth):
        def apply_rules(axiom, rules):
            result = ""
            for char in axiom:
                result += rules.get(char, char)
            return result

        rules = {
            'X': 'YF+XF+Y',
            'Y': 'XF-YF-X'
        }

        axiom = 'YF'
        for _ in range(depth):
            axiom = apply_rules(axiom, rules)

        return axiom

    def generate_sierpinski_arrowhead(self, depth=4, size=10.0):
        lsystem_string = self.sierpinski_arrowhead_lsystem(depth)
        segments = []
        x, y = 0.0, 0.0
        direction = 0
        angle_step = 60
        step = size / (2 ** depth) if depth > 0 else size
        stack = []

        for char in lsystem_string:
            if char == 'F':
                angle_rad = np.radians(direction)
                new_x = x + step * np.cos(angle_rad)
                new_y = y + step * np.sin(angle_rad)
                segments.append(((x, y), (new_x, new_y)))
                x, y = new_x, new_y
            elif char == '+':
                direction += angle_step
            elif char == '-':
                direction -= angle_step
            elif char == '[':
                stack.append((x, y, direction))
            elif char == ']':
                if stack:
                    x, y, direction = stack.pop()

        self.segments = segments
        return segments

    def gosper_curve_lsystem(self, depth):
        def apply_rules(axiom, rules):
            result = ""
            for char in axiom:
                result += rules.get(char, char)
            return result

        rules = {
            'A': 'A-B--B+A++AA+B-',
            'B': '+A-BB--B-A++A+B'
        }

        axiom = 'A'
        for _ in range(depth):
            axiom = apply_rules(axiom, rules)

        return axiom

    def generate_gosper_curve(self, depth=3, size=10.0):
        lsystem_string = self.gosper_curve_lsystem(depth)
        segments = []
        x, y = 0.0, 0.0
        direction = 0
        angle_step = 60
        step = size / (3 ** (depth - 1)) if depth > 1 else size
        stack = []

        for char in lsystem_string:
            if char == 'A' or char == 'B':
                angle_rad = np.radians(direction)
                new_x = x + step * np.cos(angle_rad)
                new_y = y + step * np.sin(angle_rad)
                segments.append(((x, y), (new_x, new_y)))
                x, y = new_x, new_y
            elif char == '+':
                direction += angle_step
            elif char == '-':
                direction -= angle_step
            elif char == '[':
                stack.append((x, y, direction))
            elif char == ']':
                if stack:
                    x, y, direction = stack.pop()

        self.segments = segments
        return segments

    def segments_to_z3(self, segments=None):
        if segments is None:
            segments = self.segments

        z3_segments = []
        for i, (start_pt, end_pt) in enumerate(segments):
            start_z3 = Point.create(f"seg_{i}_start", start_pt[0], start_pt[1])
            end_z3 = Point.create(f"seg_{i}_end", end_pt[0], end_pt[1])
            z3_segments.append(Segment.create(start_z3, end_z3))

        return z3_segments