import z3

class Point:
    """Represents a point in 2D space with Z3 symbolic variables."""

    def __init__(self, name, x, y):
        self.name = name
        self.x = z3.Real(name + '_x')
        self.y = z3.Real(name + '_y')
        self.concrete_x = x
        self.concrete_y = y

    @classmethod
    def create(cls, name, x, y):
        return cls(name, x, y)

class Segment:
    """Represents a line segment with start and end points."""

    def __init__(self, start, end):
        self.start = start
        self.end = end

    @classmethod
    def create(cls, start, end):
        return cls(start, end)