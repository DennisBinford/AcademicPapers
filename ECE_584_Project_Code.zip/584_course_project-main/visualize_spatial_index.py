"""
visualize_spatial_index.py - Generate heatmaps of spatial index distribution

This script visualizes how segments are distributed across grid cells
for different fractals at various grid sizes.

Configure which fractals, depths, and grid sizes to visualize below.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from fractal_generators import FractalGenerator
from verifier import SpatialIndex
import os
import csv
from datetime import datetime

# ============================================================================
# CONFIGURATION - Edit these to control what gets visualized
# ============================================================================

# Which fractals to visualize (keys from FRACTAL_CONFIG)
FRACTALS_TO_VISUALIZE = ['koch', 'dragon', 'levy', 'hilbert', 'sierpinski', 'gosper']

# Fractal configurations (same as main.py)
FRACTAL_CONFIG = {
    'koch': {
        'name': 'Koch Curve',
        'method': 'generate_koch_curve',
        'depths': [5, 7, 9]  # Specific depths to visualize
    },
    'dragon': {
        'name': 'Heighway Dragon',
        'method': 'generate_heighway_dragon',
        'depths': [6, 8, 10]
    },
    'levy': {
        'name': 'Lévy C Curve',
        'method': 'generate_levy_curve',
        'depths': [6, 8, 10]
    },
    'hilbert': {
        'name': 'Hilbert Curve',
        'method': 'generate_hilbert_curve',
        'depths': [4, 5, 6]
    },
    'sierpinski': {
        'name': 'Sierpiński Arrowhead',
        'method': 'generate_sierpinski_arrowhead',
        'depths': [4, 5, 6]
    },
    'gosper': {
        'name': 'Gosper Curve',
        'method': 'generate_gosper_curve',
        'depths': [3, 4, 5]
    }
}

# Grid sizes to visualize
GRID_SIZES = [10, 50, 100]

# Generate individual heatmaps (one per fractal/depth/grid_size combination)
GENERATE_INDIVIDUAL_HEATMAPS = True

# Generate comparison plots (multiple grid sizes side-by-side for each fractal/depth)
GENERATE_COMPARISON_PLOTS = True

# Output directory
OUTPUT_DIR = "heatmaps"

# ============================================================================
# PLOTTING FUNCTIONS
# ============================================================================

def create_spatial_index_heatmap(segments, grid_size, fractal_name, depth,
                                 output_dir="heatmaps"):
    """
    Create a heatmap showing segment distribution across spatial index grid.

    Args:
        segments: List of (start, end) tuples
        grid_size: Size of the spatial grid (e.g., 10 for 10x10)
        fractal_name: Name of the fractal
        depth: Depth/iteration of the fractal
        output_dir: Directory to save the heatmap

    Returns:
        Tuple of (path to saved heatmap file, statistics dict)
    """
    # Create output directory if needed
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Convert segments to Z3 segments for spatial index
    generator = FractalGenerator()
    z3_segments = generator.segments_to_z3(segments)

    # Create spatial index
    spatial_index = SpatialIndex(z3_segments, grid_size=grid_size)

    # Create grid to count segments per cell
    grid = np.zeros((grid_size, grid_size))

    # Count segments in each cell
    for cell, indices in spatial_index.cells.items():
        cell_x, cell_y = cell
        grid[cell_y, cell_x] = len(indices)

    # Calculate statistics
    total_segments = len(segments)
    occupied_cells = np.sum(grid > 0)
    avg_segments_per_occupied = np.mean(grid[grid > 0]) if occupied_cells > 0 else 0
    max_segments_per_cell = np.max(grid)
    min_segments_per_cell = np.min(grid[grid > 0]) if occupied_cells > 0 else 0

    stats = {
        'fractal_name': fractal_name,
        'depth': depth,
        'grid_size': grid_size,
        'total_segments': total_segments,
        'total_cells': grid_size ** 2,
        'occupied_cells': int(occupied_cells),
        'avg_segments_per_occupied_cell': avg_segments_per_occupied,
        'max_segments_per_cell': int(max_segments_per_cell),
        'min_segments_per_cell': int(min_segments_per_cell)
    }

    # Create figure
    fig, ax = plt.subplots(figsize=(12, 10))

    # Use log scale if there's high variance
    max_count = np.max(grid)
    min_count = np.min(grid[grid > 0]) if np.any(grid > 0) else 1

    if max_count / min_count > 100:
        # Use log scale for high variance
        im = ax.imshow(grid, cmap='YlOrRd', origin='lower',
                       norm=LogNorm(vmin=max(0.1, min_count), vmax=max_count),
                       interpolation='nearest')
        cbar_label = 'Segments per Cell (log scale)'
    else:
        # Use linear scale for low variance
        im = ax.imshow(grid, cmap='YlOrRd', origin='lower',
                       interpolation='nearest')
        cbar_label = 'Segments per Cell'

    # Add colorbar
    cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label(cbar_label, fontsize=12)

    # Add grid lines
    ax.set_xticks(np.arange(-0.5, grid_size, 1), minor=True)
    ax.set_yticks(np.arange(-0.5, grid_size, 1), minor=True)
    ax.grid(which='minor', color='gray', linestyle='-', linewidth=0.5, alpha=0.3)

    # Set major ticks
    tick_spacing = max(1, grid_size // 10)
    ax.set_xticks(np.arange(0, grid_size, tick_spacing))
    ax.set_yticks(np.arange(0, grid_size, tick_spacing))

    # Labels and title
    ax.set_xlabel('Grid Cell X', fontsize=12)
    ax.set_ylabel('Grid Cell Y', fontsize=12)

    title = f'{fractal_name}\n'
    title += f'Depth {depth}\n'
    title += f'Spatial Index: {grid_size}×{grid_size} Grid'

    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)

    plt.tight_layout()

    # Save figure
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    safe_name = fractal_name.replace(' ', '_').replace('é', 'e').replace('ń', 'n')
    filename = os.path.join(output_dir,
                            f'{safe_name}_d{depth}_grid{grid_size}_{timestamp}.png')
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()

    return filename, stats


def create_multi_grid_comparison(segments, grid_sizes, fractal_name, depth,
                                 output_dir="heatmaps"):
    """
    Create a comparison plot showing multiple grid sizes side by side.

    Args:
        segments: List of (start, end) tuples
        grid_sizes: List of grid sizes to compare (e.g., [10, 50, 100])
        fractal_name: Name of the fractal
        depth: Depth/iteration of the fractal
        output_dir: Directory to save the comparison plot

    Returns:
        Tuple of (path to saved comparison plot, list of statistics dicts)
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Convert segments to Z3 segments
    generator = FractalGenerator()
    z3_segments = generator.segments_to_z3(segments)

    num_grids = len(grid_sizes)
    fig, axes = plt.subplots(1, num_grids, figsize=(6 * num_grids, 5))

    if num_grids == 1:
        axes = [axes]

    all_stats = []

    for idx, grid_size in enumerate(grid_sizes):
        ax = axes[idx]

        # Create spatial index
        spatial_index = SpatialIndex(z3_segments, grid_size=grid_size)

        # Create grid
        grid = np.zeros((grid_size, grid_size))
        for cell, indices in spatial_index.cells.items():
            cell_x, cell_y = cell
            grid[cell_y, cell_x] = len(indices)

        # Calculate statistics
        occupied_cells = np.sum(grid > 0)
        avg_segments = np.mean(grid[grid > 0]) if occupied_cells > 0 else 0

        stats = {
            'fractal_name': fractal_name,
            'depth': depth,
            'grid_size': grid_size,
            'total_segments': len(segments),
            'total_cells': grid_size ** 2,
            'occupied_cells': int(occupied_cells),
            'avg_segments_per_occupied_cell': avg_segments,
            'max_segments_per_cell': int(np.max(grid)),
            'min_segments_per_cell': int(np.min(grid[grid > 0])) if occupied_cells > 0 else 0
        }
        all_stats.append(stats)

        # Plot
        max_count = np.max(grid)
        min_count = np.min(grid[grid > 0]) if np.any(grid > 0) else 1

        if max_count / min_count > 100:
            im = ax.imshow(grid, cmap='YlOrRd', origin='lower',
                           norm=LogNorm(vmin=max(0.1, min_count), vmax=max_count),
                           interpolation='nearest')
        else:
            im = ax.imshow(grid, cmap='YlOrRd', origin='lower',
                           interpolation='nearest')

        # Add colorbar
        cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.ax.tick_params(labelsize=9)

        # Grid lines
        if grid_size <= 20:
            ax.set_xticks(np.arange(-0.5, grid_size, 1), minor=True)
            ax.set_yticks(np.arange(-0.5, grid_size, 1), minor=True)
            ax.grid(which='minor', color='gray', linestyle='-', linewidth=0.5, alpha=0.3)

        # Subplot title
        ax.set_title(f'{grid_size}×{grid_size} Grid',
                     fontsize=11, fontweight='bold')
        ax.set_xlabel('Grid X', fontsize=10)
        ax.set_ylabel('Grid Y', fontsize=10)

    # Main title
    fig.suptitle(f'{fractal_name}\nDepth {depth}',
                 fontsize=14, fontweight='bold')
    plt.tight_layout()

    # Save
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    safe_name = fractal_name.replace(' ', '_').replace('é', 'e').replace('ń', 'n')
    filename = os.path.join(output_dir,
                            f'{safe_name}_d{depth}_comparison_{timestamp}.png')
    plt.savefig(filename, dpi=150, bbox_inches='tight')
    plt.close()

    return filename, all_stats


def save_heatmap_statistics(all_stats, output_dir="heatmaps"):
    """
    Save heatmap statistics to a CSV file.

    Args:
        all_stats: List of statistics dictionaries
        output_dir: Directory to save the CSV file
    """
    if not all_stats:
        return None

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = os.path.join(output_dir, f'heatmap_statistics_{timestamp}.csv')

    fieldnames = [
        'fractal_name',
        'depth',
        'grid_size',
        'total_segments',
        'total_cells',
        'occupied_cells',
        'avg_segments_per_occupied_cell',
        'max_segments_per_cell',
        'min_segments_per_cell'
    ]

    with open(filename, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for stats in all_stats:
            writer.writerow(stats)

    print(f"  💾 Heatmap statistics saved to: {filename}")
    return filename


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """Generate heatmaps based on configuration."""
    generator = FractalGenerator()
    generated_files = []
    all_statistics = []

    print(f"\n{'=' * 70}")
    print("SPATIAL INDEX HEATMAP GENERATION".center(70))
    print(f"{'=' * 70}\n")

    print(f"Configuration:")
    print(f"  Fractals to visualize: {', '.join(FRACTALS_TO_VISUALIZE)}")
    print(f"  Grid sizes: {GRID_SIZES}")
    print(f"  Individual heatmaps: {'ENABLED' if GENERATE_INDIVIDUAL_HEATMAPS else 'DISABLED'}")
    print(f"  Comparison plots: {'ENABLED' if GENERATE_COMPARISON_PLOTS else 'DISABLED'}")
    print(f"  Output directory: {OUTPUT_DIR}/\n")

    for fractal_key in FRACTALS_TO_VISUALIZE:
        if fractal_key not in FRACTAL_CONFIG:
            print(f"⚠️  Warning: '{fractal_key}' not found in FRACTAL_CONFIG, skipping")
            continue

        config = FRACTAL_CONFIG[fractal_key]
        print(f"\n{'=' * 70}")
        print(f"{config['name']}".center(70))
        print(f"{'=' * 70}")

        method = getattr(generator, config['method'])

        for depth in config['depths']:
            print(f"\n  Processing depth {depth}:")
            print(f"    Generating fractal...", end=' ')
            try:
                segments = method(depth)
                print(f"✓ {len(segments):,} segments")
            except Exception as e:
                print(f"✗ Error: {e}")
                continue

            # Generate individual heatmaps
            if GENERATE_INDIVIDUAL_HEATMAPS:
                for grid_size in GRID_SIZES:
                    print(f"    Creating {grid_size}×{grid_size} heatmap...", end=' ')
                    try:
                        filepath, stats = create_spatial_index_heatmap(
                            segments, grid_size, config['name'], depth, OUTPUT_DIR
                        )
                        generated_files.append(filepath)
                        all_statistics.append(stats)
                        print(f"✓ Saved")
                    except Exception as e:
                        print(f"✗ Error: {e}")

            # Generate comparison plot
            if GENERATE_COMPARISON_PLOTS:
                print(f"    Creating multi-grid comparison...", end=' ')
                try:
                    filepath, stats_list = create_multi_grid_comparison(
                        segments, GRID_SIZES, config['name'], depth, OUTPUT_DIR
                    )
                    generated_files.append(filepath)
                    # Don't add stats_list since we already added them above
                    print(f"✓ Saved")
                except Exception as e:
                    print(f"✗ Error: {e}")

    # Save statistics to CSV
    if all_statistics:
        print(f"\n{'=' * 70}")
        print(f"Saving statistics...")
        csv_file = save_heatmap_statistics(all_statistics, OUTPUT_DIR)

    print(f"\n{'=' * 70}")
    print(f"HEATMAP GENERATION COMPLETE".center(70))
    print(f"{'=' * 70}")
    print(f"\n✓ Generated {len(generated_files)} heatmap files in {OUTPUT_DIR}/")
    print()


if __name__ == "__main__":
    main()